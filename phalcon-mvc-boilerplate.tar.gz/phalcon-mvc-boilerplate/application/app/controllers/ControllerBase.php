<?php

use Phalcon\Mvc\Controller;

class ControllerBase extends Controller
{

    protected function initialize()
    {
        $this->tag->prependTitle('Table Matrix | ');
        $this->view->setTemplateAfter('main');
    }
}
