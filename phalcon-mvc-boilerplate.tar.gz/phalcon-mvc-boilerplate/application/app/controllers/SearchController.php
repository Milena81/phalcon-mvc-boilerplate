<?php

use Phalcon\Filter;


class SearchController extends ControllerBase
{
    public function initialize()
    {
        $this->tag->setTitle('Search');
        parent::initialize();

        $this->filter = new Filter();

        $this->skills = $this->getAllSkills();
        $this->allUserSkills = $this->getAllUserSkills();
    }

    public function indexAction()
    {
        if($this->request->isPost()) {
            $this->post = $this->normalizePost($this->request->getPost());

            $usersScore = $this->setScoreBySearch();

            $orderBy = array_keys($usersScore);

            uksort($this->allUserSkills, function($key1, $key2) use ($orderBy) {
                return (array_search($key1, $orderBy) > array_search($key2, $orderBy));
            });

            $this->view->result = $this->allUserSkills;
            $this->view->users = $this->getAllUsers();
            $this->view->maxScore = $this->getMaxScore();
            $this->view->usersScore = $usersScore;
        }


        $this->view->skills = $this->skills;
        $this->view->post = $this->request->getPost();
    }

    private function getMaxScore() {

        $score = count($this->post);

        foreach ($this->post as $key => $value) {

            if($value['years'] > 0)
                $score += 1;

            if($value['experience'] > 0)
                $score += 1;
        }

        return $score;
    }

    private function setScoreBySearch() {

        $usersScore = array();

        foreach ($this->post as $skillId => $details) {

            foreach ($this->allUserSkills as $userId => $value) {

                if(!isset($usersScore[$userId]))
                    $usersScore[$userId] = 0;

                if(!isset($this->allUserSkills[$userId][$skillId]))
                    continue;

                if($details['experience'] > 0 && $this->allUserSkills[$userId][$skillId]['experience'] >= $details['experience'])
                    $usersScore[$userId] +=1;

                if($details['years'] > 0 && $this->allUserSkills[$userId][$skillId]['years'] >= $details['years'])
                    $usersScore[$userId] +=1;

                foreach ($value as $s_id => $v) {
                    if($skillId == $s_id) {
                        $usersScore[$userId] +=1;
                        break;
                    }
                }
            }
        }

        arsort($usersScore);

        return $usersScore;
    }

    private function getAllUserSkills() {
        $skills = UsersSkills::find();

        $data = array();

        foreach($skills as $key => $value) {
            $data[$value->user_id][$value->skill_id] = array(
                'experience' => $value->experience,
                'years'      => $value->years
            );
        }

        return $data;
    }

    private function normalizePost($post) {

        $search = [];

        if(isset($post['skill'])) {
            foreach ($post['skill'] as $key => $skill) {
                $search[$key] = array(
                    'experience' => $this->filter->sanitize($post['experience'][$key], 'int'),
                    'years' => $this->filter->sanitize($post['years'][$key], 'int'),
                );
            }
        }

        return $search;
    }

    private function getAllSkills() {

        $skills = Skills::find();

        $data = array();

        foreach ($skills as $skill) {
            $data[$skill->id] = $skill->name;
        }

        return $data;
    }

    private function getAllUsers() {

        $users = Users::find();

        $data = array();

        foreach ($users as $user) {
            $data[$user->id] = array(
                'name' => $user->name,
                'email' => $user->email,
            );
        }

        return $data;
    }
}
