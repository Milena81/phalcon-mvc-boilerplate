<?php

use Phalcon\Filter;

/**
 * ContactController
 *
 * Allows to contact the staff using a contact form
 */
class SkillsController extends ControllerBase
{
    public function initialize()
    {
        $this->tag->setTitle('Skills');
        $this->auth = $this->session->get('auth');
        $this->skills = $this->getAllSkills()->toArray();
        $this->filter = new Filter();
        parent::initialize();
    }

    public function indexAction()
    {
        if($this->request->isPost()) {
            $post = $this->request->getPost('skills');
            $this->setSkills($post);
        }

        $mySkills = $this->getMySkills()->toArray();

        $this->view->skills = $this->skills;
        $this->view->unusedSkills = $this->getUnusedSkills($mySkills);
        $this->view->jsonSkills = json_encode($this->getUnusedSkills($mySkills));
        $this->view->mySkills = $mySkills;
    }

    private function getUnusedSkills($mySkills) {

        $skills = $this->skills;

        if(count($mySkills) > 0) {
            foreach ($mySkills as $mySkill) {
                $mySkill = $mySkill['skill_id'];

                foreach ($skills as $key => $skill) {
                    if($mySkill == $skill['id']) {
                        unset($skills[$key]);
                        break;
                    }
                }
            }
        }

        return $skills;
    }

    private function setSkills($post) {

        $this->deleteMySkills();

        foreach($post as $value) {

            $skill = $this->filter->sanitize($value['skill'], 'int');
            $experience = $this->filter->sanitize($value['experience'], 'int');
            $years = $this->filter->sanitize($value['years'], 'int');

            if($skill == 0 || $experience == 0 || $years == 0) {
                continue;
            }

            $mySkills = $this->getMySkills()->toArray();

            if(array_search($skill, array_column($mySkills, 'skill_id')) !== false) {
                continue;
            }

            $userSkills = new UsersSkills();

            $userSkills->user_id = $this->auth['id'];
            $userSkills->skill_id = $skill;
            $userSkills->years = $years;
            $userSkills->experience = $experience;
            $userSkills->save();

        }
    }

    private function deleteMySkills() {

        $mySkills = $this->getMySkills();

        if ($mySkills !== false) {
            $mySkills->delete();
        }
    }

    private function getAllSkills() {

        $skills = Skills::find();

        return $skills;
    }

    private function getMySkills() {

        $skills = UsersSkills::findByUserId($this->auth['id']);

        return $skills;
    }

}
