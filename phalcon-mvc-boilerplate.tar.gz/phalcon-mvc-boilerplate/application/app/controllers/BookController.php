<?php

use Phalcon\Mvc\Model;
use Phalcon\Filter;

class BookController extends ControllerBase
{
    public function initialize()
    {
        $this->tag->setTitle('Book');
        $this->auth = $this->session->get('auth');
        $this->filter = new Filter();
        parent::initialize();

    }

    public function deleteAction($id)
    {
        $book = Book::findFirstById($id);

        if($book) {
            $book->delete();
            return $this->response->redirect('book/index');
        } else {
            $this->flash->error('There is no book with this ID');
        }
    }

    public function indexAction()
    {
        /**
         * array(8) {
         * ["email"]=> string(10) "asd@abv.bg"
         * ["password"]=> string(0) ""
         * ["address"]=> string(39) "asdasd, asdsdsdsd, asdsdsdsd, asdsdsdsd"
         * ["address2"]=> string(9) "asdsdsdsd"
         * ["city"]=> string(7) "Plovdiv"
         * ["zip"]=> string(4) "5555"
         * ["check"]=> string(2) "on"
         * ["submit"]=> string(0) "" }
         */

        /*1. to visualise an array of object of books;
        2.*/


//        $this->view->books = $this->books;
//        $this->view->unusedSkills = $this->getUnusedSkills($mySkills);
//        $this->view->jsonSkills = json_encode($this->getUnusedSkills($mySkills));
//        $this->view->mySkills = $mySkills;

        //$books = $this->getMyBooks()->toArray();

        //$this->view->books = 'object_of_books';


        /* the fields */
        $email = $this->request->getPost('email');
        $password = $this->request->getPost('password');
        $address = $this->request->getPost('address');
        $address2 = $this->request->getPost('address2');
        $city = $this->request->getPost('city');
        $zip = $this->request->getPost('zip');
        $state = $this->request->getPost('state');
        $status = $this->request->getPost('check') == 'on' ? 1 : 0;
        $submit = $this->request->getPost('submit');


        if (isset($submit)) {

            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $this->flash->error('Your email is not valid');
                return true;
            }

            if (strlen($password) < 5) {
                $this->flash->error('Your password is too short');
                return true;
            }


            $book = new Book();

            $book->date_added = time();
            $book->email = $email;
            $book->password = $password;
            $book->address = $address;

            if (isset($address2)) {
                $book->address2 = $address2;
            }

            $book->city = $city;
            $book->zip = $zip;
            $book->state = $state;
            $book->status = $status;
            if ($book->save()) {
                $this->flash->success('You successfuly added new book information');
            } else {

                $errors = $book->getMessages();

                foreach ($errors as $error) {
                    $this->flash->error($error->getMessage());
                }
            }
        }

        $this->view->books = $this->getAllBooks()->toArray();
    }

    private function getAllBooks()
    {
        $books = Book::find([
            'order' => 'id DESC'
        ]);
        return $books;
        //var_dump($books);
    }
}
