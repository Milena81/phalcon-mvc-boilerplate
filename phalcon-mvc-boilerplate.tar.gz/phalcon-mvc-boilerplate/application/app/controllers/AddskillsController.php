<?php

use Phalcon\Filter;


class AddskillsController extends ControllerBase
{
    public function initialize()
    {
        $this->tag->setTitle('Add Skills');
        parent::initialize();

        $this->filter = new Filter();
    }

    public function indexAction()
    {
        if($this->request->isPost()) {
            $name = $this->filter->sanitize($this->request->getPost('name'), 'string');

            $skill = Skills::findFirst("name = '$name'");

            if(strlen($name) == 0) {
                $this->flash->error('Empty skill');
            }
            elseif($skill === false) {
                $skill = new Skills();

                $skill->name = $name;
                $skill->save();

                $this->flash->success($name. ' successfully added');
            } else {
                $this->flash->error($name. ' already exist');
            }
        }

        $this->view->skills = $this->getAllSkills();
     }

     public function deleteAction($skillId) {

        $skillId = $this->filter->sanitize($skillId, 'int');
        $skill = Skills::findFirst($skillId);

         if($skill != false && $skill->delete()) {
             return $this->response->redirect('addskills/index');
         }
     }

    private function getAllSkills() {

        $skills = Skills::find();
        return $skills;
    }
}
