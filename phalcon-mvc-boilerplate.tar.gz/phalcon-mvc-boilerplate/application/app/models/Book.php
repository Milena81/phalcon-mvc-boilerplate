<?php

use Phalcon\Mvc\Model;
use Phalcon\Validation;
use Phalcon\Validation\Validator\Email;

/**
 * Types of Products
 */
class Book extends Model
{

    public $id;
    public $date_added;
    public $email;
    public $password;
    public $address;
    public $address2;
    public $city;
    public $state;
    public $zip;
    public $status;

    public function validation()
    {
/*        $validation = new Validation();

        $validation->add(
            'email',
            new Email(
                [
                    'message' => 'The e-mail is not valid',
                ]
            )
        );

        return $this->validate($validation);*/
    }

    public function initialize()
    {
        $this->setSource('book');
    }

}