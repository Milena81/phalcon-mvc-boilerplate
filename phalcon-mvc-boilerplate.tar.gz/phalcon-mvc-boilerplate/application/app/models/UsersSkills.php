<?php

use Phalcon\Mvc\Model;

/**
 * Types of Products
 */
class UsersSkills extends Model
{

    public function initialize()
    {
        $this->setSource('users_skills');
    }
}