<?php

use Phalcon\Mvc\Model;
use Phalcon\Validation;
use Phalcon\Validation\Validator\Email;

class UserBooks extends Model
{
    public $id;
    public $date_added;
    public $email;
    public $password;
    public $address;
    public $address2;
    public $city;
    public $state;
    public $zip;
    public $status;

    public function initialize()
    {
        $this->setSource('book');       //the name of the table

    }

}