<?php

use Phalcon\Mvc\Model;

/**
 * Types of Products
 */
class Skills extends Model
{

    public $id;

    public $name;

    public function initialize()
    {
        $this->setSource('skills');
    }
}