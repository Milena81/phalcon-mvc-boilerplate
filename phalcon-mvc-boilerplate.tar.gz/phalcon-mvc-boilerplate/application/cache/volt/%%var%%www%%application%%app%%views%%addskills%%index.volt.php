<form action="" method="post">
    <div class="add-holder">
        <div class="input-group">
            <input name="name" type="text" class="form-control" placeholder="Add new skill">
            <span class="input-group-btn">
        <button class="btn btn-primary" type="submit">Add it!</button>
      </span>
        </div>
    </div>
</form>
<br/><br/>
<div>
    <?php foreach ($skills as $key => $skill) { ?>
        <input data-on-confirm="deleteSkill" data-id="<?= $skill->id ?>" data-title="Delete this skill"
        data-toggle="confirmation" style="margin-bottom: 5px" class="btn btn-info" type="button" value="<?= $skill->name ?>">
    <?php } ?>
</div>
<script>
    $('[data-toggle=confirmation]').confirmation({
        rootSelector: '[data-toggle=confirmation]',
    });

    function deleteSkill() {
        var id = $(this)[0].getAttribute('data-id');
        location.href="./delete/" + id;
    }
</script>
<style>
    .add-holder {
        width: 400px;
        text-align: center;
        margin: 0 auto;
    }
</style>