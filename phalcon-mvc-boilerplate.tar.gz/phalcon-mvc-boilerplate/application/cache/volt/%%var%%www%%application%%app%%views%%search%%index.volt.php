<div>
    <table class="search-table table">
        <thead>
        <tr>
            <th>Skill Name</th>
            <th>Skill Level</th>
            <th>Years Experience</th>
        </tr>
        </thead>
        <tbody>
        <form action="" method="post" class="form-inline text-left" role="form">
        <?php foreach ($skills as $skillId => $skillName) { ?>
            <tr>
                <td>
                    <input <?= ((isset($post) && isset($post['skill'][$skillId]) ? 'checked' : '')) ?> id="skill-<?= $skillId ?>" type="checkbox" name="skill[<?= $skillId ?>]" value="<?= $skillName ?>">
                    <label for="skill-<?= $skillId ?>"><?= $skillName ?></label>
                </td>
                <td>
                    <select class="form-control" name="experience[<?= $skillId ?>]">
                        <option value="0">Skill level (optional)...</option>
                        <?php foreach (range(1, 10) as $i) { ?>
                            <option <?= ((isset($post['experience']) && $post['experience'][$skillId] == $i ? 'selected' : '')) ?> value="<?= $i ?>">
                                <?php if ($i > 1) { ?>
                                    <?= 'more than ' . $i ?>
                                <?php } else { ?>
                                    <?= 'more than ' . $i ?>
                                <?php } ?>
                            </option>
                        <?php } ?>
                    </select>
                </td>
                <td>
                    <select class="form-control" name="years[<?= $skillId ?>]">
                        <option value="0">Years experience (optional)...</option>
                        <?php foreach (range(1, 10) as $i) { ?>
                            <option <?= ((isset($post['years']) && $post['years'][$skillId] == $i ? 'selected' : '')) ?> value="<?= $i ?>">
                                <?php if ($i > 1) { ?>
                                    <?= 'more than ' . $i . ' years' ?>
                                <?php } else { ?>
                                    <?= 'more than ' . $i . ' year' ?>
                                <?php } ?>
                            </option>
                        <?php } ?>
                    </select>
                </td>
            </tr>
        <?php } ?>
            <tr>
                <td align="center" colspan="3"><input type="submit" class="btn btn-primary btn-lg" value="Search"></td>
            </tr>
        </form>
        </tfoot>
    </table>
    <?php if (isset($result) && isset($post['skill'])) { ?>
        <h2 class="text-center">The results are sorted by best matches</h2>
        <?php foreach ($result as $userId => $data) { ?>
            <div>
                <table class="table table-bordered">
                        <tr>
                            <th class="text-center" colspan="<?= $this->length($post['skill']) + 1 ?>">
                                <div>
                                    <i class="fas fa-user"></i>&nbsp;<?= $users[$userId]['name'] ?>
                                </div>
                                <div>
                                    <i class="fas fa-envelope-open"></i>&nbsp;<?= $users[$userId]['email'] ?>
                                </div>
                                <div><i class="fas fa-star"></i>&nbsp;<?= $usersScore[$userId] . ' / ' . $maxScore ?></div>
                                <div><i class="fas fa-sort-amount-down"></i>&nbsp;<?= number_format(($usersScore[$userId] / $maxScore * 100), 2) ?>%</div>
                            </th>
                        </tr>
                        <th></th>
                        <?php foreach ($post['skill'] as $skill) { ?>
                            <th class="text-center"><?= $skill ?></th>
                        <?php } ?>
                        <?php foreach (range(10, 1) as $i) { ?>
                            <tr>
                                <td width="40" align="center"><?= $i ?></td>
                                <?php foreach ($post['skill'] as $skillId => $skill) { ?>
                                    <?php if (isset($data[$skillId])) { ?>
                                        <?php if ($data[$skillId]['years'] == $i) { ?>
                                            <td class="success" width="40" align="center"><strong><?= $data[$skillId]['experience'] ?></strong></td>
                                        <?php } else { ?>
                                            <td width="40" align="center">-</td>
                                        <?php } ?>
                                    <?php } else { ?>
                                        <td width="40" align="center">-</td>
                                    <?php } ?>
                                <?php } ?>
                            </tr>
                        <?php } ?>
                </table>
                <br/>
            </div>
        <?php } ?>
    <?php } ?>
    <?php if ($this->length($post) > 0 && !isset($post['skill'])) { ?>
        <div class="alert alert-danger">Please select the required skills</div>
    <?php } ?>
</div>
<style>
    .search-table {
        width: 600px;
        margin: 0 auto;
        text-align: left;
    }
    .table {
        width: 550px;
        margin: 0 auto;
    }
</style>