<script id="autocomplete-template" type="text/x-handlebars-template">
    <div class="row" id="row-<?= '{{ index }}' ?>">
        <div class="form-group">
            <select name="skills[<?= '{{ index }}' ?>][skill]" class="form-control skill">
                <option value="0">Select skill...</option>
                <?= '{{#each skills }}' ?>
                    <option value="<?= '{{ id }}' ?>"><?= '{{ name }}' ?></option>
                <?= '{{/each }}' ?>
            </select>
        </div>
        <div class="form-group">
            <select name="skills[<?= '{{ index }}' ?>][experience]" class="form-control">
                <option value="0">Select experience...</option>
                <?php foreach (range(1, 10) as $i) { ?>
                    <option value="<?= $i ?>"><?= $i ?><?php if ($i == 1) { ?> - Beginner <?php } elseif ($i == 10) { ?> - Expert <?php } elseif ($i == 5) { ?> - Intermediate<?php } ?></option>
                <?php } ?>
            </select>
        </div>
        <div class="form-group">
            <select name="skills[<?= '{{ index }}' ?>][years]" class="form-control">
                <option value="0">Select years...</option>
                <?php foreach (range(1, 10) as $i) { ?>
                    <option value="<?= $i ?>">
                        <?= $i . (($i == 10 ? '+' : '')) . (($i == 1 ? ' year' : ' years')) ?>
                        <?php if ($i == 1) { ?>
                            - Beginner
                        <?php } elseif ($i == 5) { ?>
                            - Expert
                        <?php } elseif ($i == 3) { ?>
                            - Intermediate
                        <?php } ?>
                    </option>
                <?php } ?>
            </select>
        </div>
        <a href="javascript:;" id="addnew-<?= '{{ index }}' ?>" class="addnew btn btn-primary"><i class="fas fa-plus-circle"></i></a>
    </div>
</script>


<div class="alert alert-info">Please setup your skills</div>
<form action="" method="post" class="form-inline text-center" role="form">
    <?php if (isset($mySkills) && $this->length($mySkills) > 0) { ?>
        <?php foreach ($mySkills as $mySkill) { ?>
            <div class="mySkills">
                <div class="row" id="my-skill-row-<?= $mySkill['id'] ?>">
                    <div class="form-group">
                        <select name="skills[mySkill<?= $mySkill['id'] ?>][skill]" class="form-control skill">
                            <option value="0">Select skill...</option>
                            <?php foreach ($skills as $key => $skill) { ?>
                                <option <?= (($mySkill['skill_id'] == $skill['id'] ? 'selected' : '')) ?> value="<?= $skill['id'] ?>"><?= $skill['name'] ?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <select name="skills[mySkill<?= $mySkill['id'] ?>][experience]" class="form-control">
                            <option value="0">Select experience...</option>
                            <?php foreach (range(1, 10) as $i) { ?>
                                <option <?= (($mySkill['experience'] == $i ? 'selected' : '')) ?> value="<?= $i ?>"><?= $i ?><?php if ($i == 1) { ?> - Beginner <?php } elseif ($i == 10) { ?> - Expert <?php } elseif ($i == 5) { ?> - Intermediate<?php } ?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <select name="skills[mySkill<?= $mySkill['id'] ?>][years]" class="form-control">
                            <option value="0">Select years...</option>
                            <?php foreach (range(1, 10) as $i) { ?>
                                <option <?= (($mySkill['years'] == $i ? 'selected' : '')) ?> value="<?= $i ?>">
                                    <?= $i . (($i == 10 ? '+' : '')) . (($i == 1 ? ' year' : ' years')) ?>
                                    <?php if ($i == 1) { ?>
                                        - Beginner
                                    <?php } elseif ($i == 5) { ?>
                                        - Expert
                                    <?php } elseif ($i == 3) { ?>
                                        - Intermediate
                                    <?php } ?>
                                </option>
                            <?php } ?>
                        </select>
                    </div>
                    <a href="javascript:;" rel="<?= $mySkill['id'] ?>" class="remove-skill btn btn-danger"><i class="fas fa-minus-circle"></i></a>
                </div>
            </div>
        <?php } ?>
    <?php } ?>
    <div class="row" id="row-1">
        <div class="form-group">
            <select name="skills[0][skill]" class="form-control skill">
                <option value="0">Select skill...</option>
                <?php foreach ($unusedSkills as $key => $skill) { ?>
                    <option value="<?= $skill['id'] ?>"><?= $skill['name'] ?></option>
                <?php } ?>
            </select>
        </div>
        <div class="form-group">
            <select name="skills[0][experience]" class="form-control">
                <option value="0">Select experience...</option>
                <?php foreach (range(1, 10) as $i) { ?>
                    <option value="<?= $i ?>"><?= $i ?><?php if ($i == 1) { ?> - Beginner <?php } elseif ($i == 10) { ?> - Expert <?php } elseif ($i == 5) { ?> - Intermediate<?php } ?></option>
                <?php } ?>
            </select>
        </div>
        <div class="form-group">
            <select name="skills[0][years]" class="form-control">
                <option value="0">Select years...</option>
                <?php foreach (range(1, 10) as $i) { ?>
                    <option value="<?= $i ?>">
                        <?= $i . (($i == 10 ? '+' : '')) . (($i == 1 ? ' year' : ' years')) ?>
                        <?php if ($i == 1) { ?>
                            - Beginner
                        <?php } elseif ($i == 5) { ?>
                            - Expert
                        <?php } elseif ($i == 3) { ?>
                            - Intermediate
                        <?php } ?>
                    </option>
                <?php } ?>
            </select>
        </div>
        <a href="javascript:;" id="addnew-0" class="addnew btn btn-primary"><i class="fas fa-plus-circle"></i></a>
    </div>
    <div id="dynamic-container"></div>
    <div class="form-inline">
        <div class="row">
            <br/>
            <input class="form-control btn btn-success" type="submit" value="Save your skills">
        </div>
    </div>
</form>


<script>

    var index = 0;

    function addSkillField() {

        var skillsJson = <?= $jsonSkills ?>;

        index = index + 1;

        let autocompleteTpl = $('#autocomplete-template').html();
        let tplCompiled = Handlebars.compile(autocompleteTpl);

        var tpl = tplCompiled({
            skills: skillsJson,
            index: index
        });

        $('#dynamic-container').append(tpl);

    }

    $(document).on('click','.addnew',function(){
        addSkillField();

        $('.addnew:not(#addnew-'+index+')').remove();

    });


    $('.remove-skill').click(function(){
        var id = $(this).attr('rel');

        $('#my-skill-row-' + id).remove();

    });

</script>

<style>
    .row {
        margin-bottom: 10px;
    }
    .addnew, .remove-skill {
        position: absolute;
        margin-left: 10px;
    }
</style>