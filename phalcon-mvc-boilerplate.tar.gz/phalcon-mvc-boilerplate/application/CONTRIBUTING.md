## Contributing

The INVO is an open source project and a volunteer effort.
Contributions made by the community are welcome.

*We only accept bug reports, new feature requests and pull requests in GitHub*.

The INVO doesn't have human resources fully dedicated to the maintenance of this software.
If you want something to be improved or you want a new feature please submit a Pull Request.

Thanks! <br />
Phalcon Team
