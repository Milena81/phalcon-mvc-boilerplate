<?php

$config = [
	'host' => getenv('MYSQL_HOST') ? getenv('MYSQL_HOST') : false,
	'name' => getenv('MYSQL_DATABASE') ? getenv('MYSQL_DATABASE') : false,
	'user' => getenv('MYSQL_USER') ? getenv('MYSQL_USER') : false,
	'pass' => getenv('MYSQL_PASSWORD') ? getenv('MYSQL_PASSWORD') : false,
	'port' => getenv('MYSQL_PORT') ? getenv('MYSQL_PORT') : false
];

return [
	'paths'        => [
		'migrations' => './application/db/mysql/migrations',
		'seeds' => './application/db/mysql/seeds'
	],
	'environments' => [
		'default_database'        => $config['name'],
		'default_migration_table' => 'phinxlog',
		'development'             => [
			'adapter' => 'mysql',
			'host'    => $config['host'],
			'name'    => $config['name'],
			'user'    => $config['user'],
			'pass'    => $config['pass'],
			'port'    => $config['port'],
		],
		'staging'                 => [
			'adapter' => 'mysql',
			'host'    => $config['host'],
			'name'    => $config['name'],
			'user'    => $config['user'],
			'pass'    => $config['pass'],
			'port'    => $config['port'],
		],
		'master'                  => [
			'adapter' => 'mysql',
			'host'    => $config['host'],
			'name'    => $config['name'],
			'user'    => $config['user'],
			'pass'    => $config['pass'],
			'port'    => $config['port'],
		],
        'production'                  => [
            'adapter' => 'mysql',
            'host'    => $config['host'],
            'name'    => $config['name'],
            'user'    => getenv('MYSQL_MIGRATOR_USER') ? getenv('MYSQL_MIGRATOR_USER') : false,
            'pass'    => getenv('MYSQL_MIGRATOR_PASSWORD') ? getenv('MYSQL_MIGRATOR_PASSWORD') : false,
            'port'    => $config['port'],
        ],
	],
];
