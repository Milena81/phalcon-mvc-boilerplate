#!/bin/sh
set -e

# first arg is `-f` or `--some-option`
if [ "${1#-}" != "$1" ]; then
	set -- php "$@"
fi

for script in $(ls -v /opt/docker/provision/entrypoint.d/*.sh); do
	sh ${script}
done

crond -b

exec "$@"
